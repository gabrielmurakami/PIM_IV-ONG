---
name: Canopy & Earth
colors:
  surface: '#f2fcf2'
  surface-dim: '#d2ddd3'
  surface-bright: '#f2fcf2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#ecf6ec'
  surface-container: '#e6f1e7'
  surface-container-high: '#e1ebe1'
  surface-container-highest: '#dbe5dc'
  on-surface: '#151e18'
  on-surface-variant: '#414942'
  inverse-surface: '#29332c'
  inverse-on-surface: '#e9f3ea'
  outline: '#717971'
  outline-variant: '#c1c9bf'
  surface-tint: '#EFF5EC'
  primary: '#00361a'
  on-primary: '#ffffff'
  primary-container: '#1b4d2e'
  on-primary-container: '#89bd95'
  inverse-primary: '#9ed3aa'
  secondary: '#286c00'
  on-secondary: '#ffffff'
  secondary-container: '#a0f973'
  on-secondary-container: '#2b7300'
  tertiary: '#501f00'
  on-tertiary: '#ffffff'
  tertiary-container: '#733000'
  on-tertiary-container: '#ff975c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b9efc5'
  primary-fixed-dim: '#9ed3aa'
  on-primary-fixed: '#00210e'
  on-primary-fixed-variant: '#1e5031'
  secondary-fixed: '#a0f973'
  secondary-fixed-dim: '#85db5a'
  on-secondary-fixed: '#072100'
  on-secondary-fixed-variant: '#1d5200'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb690'
  on-tertiary-fixed: '#331100'
  on-tertiary-fixed-variant: '#783200'
  background: '#f2fcf2'
  on-background: '#151e18'
  surface-variant: '#dbe5dc'
  leaf-sprout: '#B0D217'
  canopy-soft: '#CFE17D'
  canvas-cream: '#F8FAF5'
  earth-sand: '#E8DDD1'
  watershed-blue: '#2A6F8F'
typography:
  display:
    fontFamily: Epilogue
    fontSize: 3.5rem
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Epilogue
    fontSize: 2.25rem
    fontWeight: '800'
    lineHeight: '1.15'
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Epilogue
    fontSize: 2.75rem
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Epilogue
    fontSize: 1.875rem
    fontWeight: '700'
    lineHeight: '1.25'
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Epilogue
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Epilogue
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Epilogue
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Epilogue
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: '1.35'
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '700'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: '1.45'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.55'
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.5'
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: '1.15'
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an inspiring, grounded, and contemporary identity for environmental collective initiatives, ecological restoration, and agroforestry education. The aesthetic bridges the raw vibrancy of the Atlantic Forest with the crisp legibility and deliberate structure of high-end editorial and modern civic platforms.

### Personality & Values
- **Vital & Living:** Dynamic greens reflect biodiversity, flourishing canopies, and regenerative action rather than sterile corporate sustainability.
- **Rooted & Trustworthy:** Earth tones and rich slate neutrals instill institutional authority, accountability, and scientific credibility.
- **Inviting & Action-Oriented:** Clean, breathable surfaces invite community participation, volunteerism, and donations without feeling overwhelming or guilt-driven.

### Design Movement
The interface employs a **Warm Modernist / Neo-Editorial** visual style. It pairs generous, deliberate whitespace and high typographic hierarchy with tactile organic accents: warm surface washes, subtle soil-toned micro-details, and crisp content containment. Elements avoid artificial glossy skeuomorphism in favor of soft, natural elevations and honest, structural composition.

## Colors

The palette draws inspiration directly from the multi-layered foliage, soil strata, and freshwater springs of the native biome.

### Roles & Applications
- **Primary (`#1B4D2E` - Deep Forest Green):** The commanding anchor. Used for primary interactive actions, high-emphasis headers, prominent brand containers, and active state highlights.
- **Secondary (`#52A429` - Leaf Green):** Represents vigor, photosynthesis, and new growth. Applied to success states, active badges, key accent buttons, and visual checkpoints.
- **Tertiary (`#B85C23` - Terracotta / Clay):** Grounding earth tone. Reserved for urgent ecological calls-to-action (e.g., immediate volunteer registration, urgent seed collection campaigns, critical alerts) and warm metadata tags.
- **Neutral (`#1E2721` - Slate Evergreen):** Deep, organic off-black with subtle forest undertones. Ensures optimal contrast and comfortable sustained reading for body copy, table text, and fine borders.

### Surface System
- Default canvas begins at `canvas-cream` (`#F8FAF5`), providing a gentler, more natural backdrop than stark pure white.
- Cards and content layers sit on pure `#FFFFFF` or `surface-tint` (`#EFF5EC`) to create natural tonal depth without relying on harsh drop shadows.

## Typography

The type system blends architectural authority with human warmth. 

- **Display & Headlines (`Epilogue`):** Characterful and sculptural, Epilogue brings robust environmental advocacy weight. Tight letter-spacing reinforces focus and determination in major statements, impact metrics, and campaign headers.
- **Body & Labels (`Plus Jakarta Sans`):** Soft geometric terminals and an open aperture ensure effortless legibility across dense educational articles, project field updates, and registration forms.

### Hierarchy & Style Rules
- Display and `headline-xl` should maintain high contrast with backgrounds and remain reserved for milestone metrics, section titles, and key takeaways.
- Labels (`label-md`, `label-sm`) use uppercase styling with positive tracking (`0.04em` to `0.06em`) when marking categories, status indicators, or data labels (e.g., "MATA ATLÂNTICA", "NASCENTE ATIVA").
- Running text never drops below 16px (`1rem`) on desktop main article bodies to support accessibility across all age demographics.

## Layout & Spacing

This design system is built around a fluid, responsive 12-column grid anchored by an 8pt rhythmic progression.

### Grid & Breakpoints
- **Desktop (1200px+):** 12 columns, max-width `1280px`, `gutter: 1.5rem`, `margin: 3rem`. Wide editorial margins provide visual calm and prioritize high-res photographic storytelling.
- **Tablet (768px – 1199px):** 8 columns, `gutter: 1.25rem`, `margin: 2rem`. Multicolumn cards reflow into 2-column modules.
- **Mobile (< 768px):** 4 columns, `gutter: 1rem`, `margin: 1.25rem`. Content stacks sequentially with full-bleed cards or compact 1rem gutters.

### Spacing Philosophy
- Macro section spacing should feel vast and unhurried (`space-xl` scaled dynamically up to `5rem` between major content zones), evoking canopy volume.
- Component internals maintain compact, cohesive unity (`space-sm` for badge interiors, `space-md` for form rows, `space-lg` for card inner paddings).

## Elevation & Depth

Visual depth avoids heavy commercial drop shadows, relying instead on clean surface tiering, subtle leaf-tinted boundaries, and organic ambient diffusion.

### Hierarchy Layers
- **Base Canvas:** `canvas-cream` (`#F8FAF5`).
- **Surface Level 1 (Cards, Modules):** `#FFFFFF` bordered with an ultra-soft organic contour (`1px solid rgba(27, 77, 46, 0.08)`).
- **Surface Level 2 (Interactive Flyouts, Active Cards, Menus):** Elevated via an ambient green-tinted shadow: `0 10px 25px -5px rgba(27, 77, 46, 0.06), 0 8px 10px -6px rgba(27, 77, 46, 0.04)`.
- **Surface Level 3 (Modals, Overlays):** Grounded on backdrop dimming (`rgba(30, 39, 33, 0.5)`) with depth `0 25px 50px -12px rgba(27, 77, 46, 0.18)`.
- **Tonal Contrast:** Sub-cards and nested data chips employ `surface-tint` (`#EFF5EC`) without borders to denote containment inside a parent white card.

## Shapes

The shape system adopts a **Rounded** posture (`roundedness: 2`), reflecting the smooth curves of seedlings, riverbeds, and leaf blades while maintaining architectural integrity.

- **Standard Elements (Buttons, Inputs, Tags):** `0.5rem` (`8px`) border-radius.
- **Surface Cards & Modules:** `rounded-lg` at `1rem` (`16px`).
- **Feature Banners & Hero Containers:** `rounded-xl` at `1.5rem` (`24px`).
- **Status Pills & Micro Badges:** Full-rounded pill (`9999px`) to distinguish categorical tags from interactive buttons.
- **Media:** Photography of native flora, fauna, and planting days mirrors the container radius (`1rem` to `1.5rem`), keeping visual rhythm synchronized.

## Components

### Buttons
- **Primary:** Background `primary_color_hex` (`#1B4D2E`), text `#FFFFFF`, radius `0.5rem`, padding `0.75rem 1.5rem`. On hover: transition to `secondary_color_hex` (`#52A429`) with subtle upward translation (`-1px`).
- **Secondary (Outlined):** `1.5px solid #1B4D2E`, background transparent, text `#1B4D2E`. Hover: background `surface-tint` (`#EFF5EC`).
- **Tertiary Action (Urgent CTA):** Background `tertiary_color_hex` (`#B85C23`), text `#FFFFFF`. Used for urgent donations, native tree sponsorships, or emergency replanting alerts.
- **Ghost:** Borderless, text `#1B4D2E`, padding `0.5rem 1rem`. Underline appears on hover.

### Chips & Badges
- **Category Chips:** Background `surface-tint` (`#EFF5EC`), text `#1B4D2E`, font token `label-md`, radius `9999px`, padding `0.25rem 0.75rem`.
- **Metric Badges:** Soil terracotta tint (`#E8DDD1`) or sprout green (`#B0D217` at 20% opacity) for ecological statistics (e.g., "12.400 MUDAS PLANTADAS", "3 NASCENTES PROTEGIDAS").

### Cards
- **Project & Impact Cards:** Background `#FFFFFF`, border `1px solid rgba(27, 77, 46, 0.08)`, radius `1rem`, padding `1.5rem`. Top section holds an image with `0.75rem` inner radius. Includes a category tag, title in `headline-sm`, summary in `body-sm`, and progress indicator for reforestation goals.
- **Stat Cards:** Background `surface-tint` (`#EFF5EC`), borderless, displaying massive numeric data in `headline-xl` (`primary_color_hex`) paired with `label-md` descriptive text below.

### Inputs & Form Controls
- **Text Inputs:** Height `48px`, background `#FFFFFF`, border `1.5px solid rgba(30, 39, 33, 0.15)`, radius `0.5rem`, padding `0 1rem`. Focus state: border color `#52A429` with a subtle box-shadow ring (`0 0 0 3px rgba(82, 164, 41, 0.15)`).
- **Checkboxes & Radios:** Size `20px`. Unchecked: `1.5px solid rgba(30, 39, 33, 0.3)`. Checked: `#1B4D2E` fill with crisp white iconography. Radii: `4px` for checkboxes, circular for radios.

### Lists & Progress Indicators
- **Data Lists:** Separated by `1px solid rgba(27, 77, 46, 0.08)`, padding `1rem 0`. Lead indicators use stylized natural leaf icons or numeric counts in `tertiary_color_hex`.
- **Canopy Progress Bar:** Container height `8px`, background `rgba(27, 77, 46, 0.1)`, fill `linear-gradient(90deg, #52A429, #B0D217)`, radius `9999px`.